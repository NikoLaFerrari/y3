# PLY package
# Author: David Beazley (dave@dabeaz.com)
# https://dabeaz.com/ply/index.html

__version__ = '4.0'
__all__ = ['lex','yacc']
